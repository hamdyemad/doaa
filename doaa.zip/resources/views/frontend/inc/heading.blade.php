<div class="heading">
    <h3 class="h1">{{ $heading }}</h3>
</div>
